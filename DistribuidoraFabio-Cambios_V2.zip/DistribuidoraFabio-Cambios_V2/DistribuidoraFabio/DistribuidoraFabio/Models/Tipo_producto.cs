﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DistribuidoraFabio.Models
{
    public class Tipo_producto
    {        
        public int id_tipoproducto { get; set; }
        public string nombre_tipo_producto { get; set; }
    }
}
