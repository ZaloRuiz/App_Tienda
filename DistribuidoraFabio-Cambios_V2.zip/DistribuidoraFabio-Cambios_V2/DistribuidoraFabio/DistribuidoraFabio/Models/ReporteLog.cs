﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DistribuidoraFabio.Models
{
    public class Reporte_Log
    {
        public int id_reporte { get; set; }
        public DateTime fecha { get; set; }
        public string descripcion { get; set; }
    }
}
