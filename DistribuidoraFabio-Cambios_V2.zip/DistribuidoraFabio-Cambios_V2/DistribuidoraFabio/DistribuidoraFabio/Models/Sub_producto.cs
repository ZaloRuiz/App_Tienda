﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DistribuidoraFabio.Models
{
    public class Sub_producto
    {
        public int id_subproducto { get; set; }
        public string nombre_sub_producto { get; set; }
    }
}
